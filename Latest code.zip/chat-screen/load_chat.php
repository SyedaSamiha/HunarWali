<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    exit('Not authenticated');
}

$currentUserId = $_SESSION['user_id'];
$otherUserId = $_GET['user_id'];

try {
    $query = "SELECT m.*, u.username as sender_name 
              FROM messages m 
              JOIN users u ON m.sender_id = u.id 
              WHERE (m.sender_id = ? AND m.receiver_id = ?) 
              OR (m.sender_id = ? AND m.receiver_id = ?) 
              ORDER BY m.created_at ASC";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("iiii", $currentUserId, $otherUserId, $otherUserId, $currentUserId);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($message = $result->fetch_assoc()) {
        $isSent = $message['sender_id'] == $currentUserId;
        $messageClass = $isSent ? 'sent' : 'received';
        
        if ($message['message_type'] === 'offer') {
            $offerData = json_decode($message['message'], true);
            $offerStatus = $offerData['status'] ?? 'pending';
            
            echo '<div class="message ' . $messageClass . '">';
            echo '<div class="message-content">';
            echo '<div class="offer-message">';
            echo '<h6>Offer Details:</h6>';
            echo '<p><strong>Amount:</strong> PKR ' . number_format($offerData['amount'], 2) . '</p>';
            echo '<p><strong>Description:</strong> ' . htmlspecialchars($offerData['description']) . '</p>';
            echo '<p><strong>Delivery Time:</strong> ' . $offerData['delivery_time'] . ' days</p>';
            
            if ($offerStatus === 'pending' && !$isSent) {
                echo '<div class="offer-actions mt-2">';
                echo '<button class="btn btn-success btn-sm me-2" onclick="respondToOffer(' . $message['id'] . ', \'accept\')">Accept</button>';
                echo '<button class="btn btn-danger btn-sm" onclick="respondToOffer(' . $message['id'] . ', \'decline\')">Decline</button>';
                echo '</div>';
            } else {
                echo '<p class="mt-2"><strong>Status:</strong> ' . ucfirst($offerStatus) . '</p>';
            }
            
            echo '</div>';
            echo '</div>';
            echo '</div>';
        } else {
            echo '<div class="message ' . $messageClass . '">';
            echo '<div class="message-content">' . htmlspecialchars($message['message']) . '</div>';
            echo '</div>';
        }
    }
} catch(Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>

<script>
function respondToOffer(messageId, response) {
    const formData = new FormData();
    formData.append('message_id', messageId);
    formData.append('response', response);

    fetch('respond_to_offer.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loadChat(selectedUserId);
        } else {
            alert('Failed to respond to offer: ' + data.message);
        }
    });
}
</script>