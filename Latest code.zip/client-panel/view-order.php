<?php
// Enable error reporting at the top of the file
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Order - Client Panel</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
            padding-top: 20px;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
            transition: 0.3s;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .sidebar a.active {
            background-color: #0d6efd;
        }
        .sidebar i {
            margin-right: 10px;
        }
        .content {
            padding: 20px;
        }
        .rating {
            display: flex;
            flex-direction: row-reverse;
            justify-content: flex-end;
        }
        .rating input {
            display: none;
        }
        .rating label {
            cursor: pointer;
            font-size: 30px;
            color: #ddd;
            padding: 5px;
        }
        .rating input:checked ~ label,
        .rating label:hover,
        .rating label:hover ~ label {
            color: #ffd700;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar">
                <h3 class="text-white text-center mb-4">Client Panel</h3>
                <nav>
                    <a href="index.php">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                    <a href="ordered-services.php" class="active">
                        <i class="fas fa-list"></i> Ordered Services
                    </a>
                    <a href="messages.php">
                        <i class="fas fa-envelope"></i> Messages
                    </a>
                    <a href="logout.php" class="mt-5">
                        <i class="fas fa-sign-out-alt"></i> Sign Out
                    </a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 content">
                <div class="container">
                    <h2 class="mb-4">Order Details</h2>
                    <?php
                    session_start();
                    require_once '../config/database.php';

                    if (!isset($_SESSION['user_id'])) {
                        header('Location: ../login/login.php');
                        exit();
                    }

                    if (!isset($_GET['id'])) {
                        header('Location: ordered-services.php');
                        exit();
                    }

                    $orderId = $_GET['id'];
                    $currentUserId = $_SESSION['user_id'];

                    try {
                        // Debug information
                        error_log("Fetching order details for ID: " . $orderId . " and user ID: " . $currentUserId);

                        $query = "
                            SELECT 
                                o.*,
                                g.gig_title,
                                g.gig_description,
                                u.username as seller_username,
                                u.email as seller_email
                            FROM orders o
                            JOIN gigs g ON o.gig_id = g.id
                            JOIN users u ON o.seller_id = u.id
                            WHERE o.id = ? AND o.buyer_id = ?
                        ";

                        $stmt = $conn->prepare($query);
                        if (!$stmt) {
                            throw new Exception("Failed to prepare statement: " . $conn->error);
                        }

                        $stmt->bind_param("ii", $orderId, $currentUserId);
                        if (!$stmt->execute()) {
                            throw new Exception("Failed to execute statement: " . $stmt->error);
                        }

                        $result = $stmt->get_result();
                        $order = $result->fetch_assoc();

                        if (!$order) {
                            throw new Exception("Order not found or you don't have permission to view it.");
                        }

                        // Debug information
                        error_log("Order details fetched successfully: " . print_r($order, true));

                    } catch (Exception $e) {
                        error_log("Error in view-order.php: " . $e->getMessage());
                        echo "<div class='alert alert-danger'>" . htmlspecialchars($e->getMessage()) . "</div>";
                        exit();
                    }
                    ?>

                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Order #<?php echo htmlspecialchars($order['id']); ?></h5>
                            <div class="row mt-4">
                                <div class="col-md-6">
                                    <h6>Service Details</h6>
                                    <p><strong>Service Name:</strong> <?php echo htmlspecialchars($order['gig_title']); ?></p>
                                    <p><strong>Description:</strong> <?php echo htmlspecialchars($order['gig_description']); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <h6>Order Information</h6>
                                    <p><strong>Status:</strong> <?php echo htmlspecialchars($order['status']); ?></p>
                                    <p><strong>Order Date:</strong> <?php echo htmlspecialchars($order['created_at']); ?></p>
                                    <p><strong>Seller:</strong> <?php echo htmlspecialchars($order['seller_username']); ?></p>
                                </div>
                            </div>
                            
                            <?php if ($order['status'] === 'Completed'): ?>
                            <div class="mt-4" id="feedback">
                                <h6>Feedback</h6>
                                <form action="submit-feedback.php" method="POST">
                                    <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($order['id']); ?>">
                                    <div class="mb-3">
                                        <label class="form-label">Rating</label>
                                        <div class="rating">
                                            <?php for($i = 5; $i >= 1; $i--): ?>
                                            <input type="radio" name="rating" value="<?php echo $i; ?>" id="star<?php echo $i; ?>" required>
                                            <label for="star<?php echo $i; ?>"><i class="fas fa-star"></i></label>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="review" class="form-label">Your Review</label>
                                        <textarea class="form-control" id="review" name="review" rows="4" placeholder="Please share your experience with this service..." required></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Submit Review</button>
                                </form>
                            </div>
                            <?php endif; ?>

                            <div class="mt-4">
                                <a href="ordered-services.php" class="btn btn-secondary">Back to Orders</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Function to scroll to feedback section
        function scrollToFeedback() {
            const feedbackSection = document.getElementById('feedback');
            if (feedbackSection) {
                feedbackSection.scrollIntoView({ behavior: 'smooth' });
            }
        }

        // Check if we should scroll to feedback section
        window.addEventListener('load', function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('section') === 'feedback') {
                scrollToFeedback();
            }
        });
    </script>
</body>
</html> 