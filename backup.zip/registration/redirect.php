<?php
// Redirect to the landing page
header("Location: landing.php");
exit;
?>